#include "plus_item.h"
#include <QBrush>
#include <QPen>
#include <QPainter>
#include <QGraphicsSceneMouseEvent>
#include <QDebug>
#include <QCursor>

CPlusItem::CPlusItem(QObject *p_parent, QGraphicsItem *item_parent)
    : QObject(p_parent), QGraphicsItem(item_parent)
{
    setCursor(QCursor(Qt::PointingHandCursor));
    setFlag(QGraphicsItem::ItemIsFocusable);
    setAcceptHoverEvents(true);
}

QRectF CPlusItem::boundingRect() const
{
    return QRectF(-10, -10, 20, 20);
}

void CPlusItem::paint(QPainter *painter,
                      const QStyleOptionGraphicsItem *option,
                      QWidget *widget)
{
    Q_UNUSED(option)
    Q_UNUSED(widget)

    if (hasFocus()) {
        painter->setPen(QPen(QBrush(QColor(255, 0, 0)), 1, Qt::DotLine));
    } else {
        painter->setPen(QPen(QBrush(QColor(255,0,0)), 1));
    }

    painter->drawLine(QPoint(-10, 0), QPoint(10, 0));
    painter->drawLine(QPoint(0, -10), QPoint(0, 10));
}

void CPlusItem::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event)
{
    qDebug() << "mouseDoubleClickEvent:" << event->pos();
}

void CPlusItem::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    qDebug() << "hoverEnterEvent:" << event->pos();
}

void CPlusItem::hoverMoveEvent(QGraphicsSceneHoverEvent *event)
{
    //qDebug() << "hoverMoveEvent:" << event->pos() << hasFocus();
}

void CPlusItem::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    qDebug() << "hoverLeaveEvent:" << event->pos();
}

void CPlusItem::focusInEvent(QFocusEvent *event)
{
    qDebug() << "focusInEvent:";
    QGraphicsItem::focusInEvent(event);
}

void CPlusItem::focusOutEvent(QFocusEvent *event)
{
    qDebug() << "focusOutEvent:";
    QGraphicsItem::focusOutEvent(event);
}
