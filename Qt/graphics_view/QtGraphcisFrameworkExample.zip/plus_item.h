#ifndef CPLUSITEM_H
#define CPLUSITEM_H

#include <QGraphicsItem>
#include <QObject>

class QPainter;
class QGraphicsSceneMouseEvent;

class CPlusItem : public QObject, public QGraphicsItem
{
    Q_OBJECT
public:
    CPlusItem(QObject *p_parent = nullptr, QGraphicsItem *item_parent = nullptr);
protected:
    QRectF boundingRect() const override;
    void paint(QPainter *painter,
               const QStyleOptionGraphicsItem *option,
               QWidget *widget = nullptr) override;
    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event) override;
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event) override;
    void hoverMoveEvent(QGraphicsSceneHoverEvent *event) override;
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event) override;
    void focusInEvent(QFocusEvent *event) override;
    void focusOutEvent(QFocusEvent *event) override;
};

#endif // CPLUSITEM_H
