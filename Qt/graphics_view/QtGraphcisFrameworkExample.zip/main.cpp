#include <QApplication>

#include <QGraphicsView>
#include <QGraphicsScene>
#include <QDebug>
#include <plus_item.h>
#include <QGraphicsRectItem>
#include <QGraphicsLineItem>
#include <QGraphicsTextItem>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QGraphicsView view;
    QGraphicsScene *p_scene = new QGraphicsScene;

    p_scene->setSceneRect(-800, -600, 1600, 1200);

    CPlusItem *p_plus_item1 = new CPlusItem;
    p_scene->addItem(p_plus_item1);
    p_plus_item1->setPos(0, 0);


    QGraphicsItemGroup *p_group = new QGraphicsItemGroup();

    QGraphicsLineItem *p_line1 = new QGraphicsLineItem(QLineF(-50, 0, 50, 0));
    p_group->addToGroup(p_line1);
    p_line1->setFlag(QGraphicsItem::ItemIsMovable);
    p_line1->setCursor(Qt::PointingHandCursor);
    p_line1->setPen(QPen(QColor(255,0,0), 2));



    QGraphicsLineItem *p_line2 = new QGraphicsLineItem(QLineF(0, -50, 0, 50));
    p_group->addToGroup(p_line2);
    p_line2->setFlag(QGraphicsItem::ItemIsMovable);
    p_line2->setCursor(Qt::PointingHandCursor);
    p_line2->setPen(QPen(QColor(255,0,0), 2));
    //p_line2->setPos(50, 50);

    p_group->setFlag(QGraphicsItem::ItemIsMovable);

    p_scene->addItem(p_group);




    view.setScene(p_scene);
    view.resize(800, 600);
    view.show();

    return a.exec();
}
